import { Router } from 'express';
import ScoreCard from '../../models/ScoreCard';

const router = Router();

router.post('/create-card', (req, res) => {
  const newName = req.body.name;
  const newSubject = req.body.subject;
  const newScore = req.body.score;
  ScoreCard.count({name: newName, subject: newSubject})
  .then( (result) => {
    if( result >= 1) {
      ScoreCard.findOneAndUpdate({name: newName, subject: newSubject}, {score: newScore});
      res.json({message: `Updating(${newName}, ${newSubject}, ${newScore})`, card: {newName, newSubject, newScore}});
    } else {
      const newUser = new ScoreCard({name: newName, subject: newSubject, score: newScore});
      newUser.save();
      res.json({message: `Adding(${newName}, ${newSubject}, ${newScore})`, card: newUser});
    }
  })
  .catch((e) => res.json({ message: `Something went wrong...${e}`}));
});

// TODO: delete the collection of the DB
router.delete('/delete', async function (req, res) {
  try {
    await ScoreCard.deleteMany({});
    res.json({message: "Database cleared."});
  } catch(e) {
    res.json({ message: 'Something went wrong...' });
  }
})

// TODO: implement the DB <query></query>
router.post('/query', (req, res) => {
  const queryType = req.body.queryType;
  const queryString = req.body.queryString;
  const query = {};
  query[queryType] = queryString;
  
  ScoreCard.find(query)
  .then(result => {
    if(result.length === 0) { 
      res.json({message: `${queryType}(${queryString}) not found!`, flag: false});
    } else {
      const findResult = result.map((r) => {return `id: ${r._id}  name: ${r.name}  subject: ${r.subject}  score: ${r.score}`});
      res.json({message: findResult, flag: true});
    }
  })
  .catch(e => { 
    res.json({ message: `Something went wrong... ${e}` });
  })
})

export default router;
